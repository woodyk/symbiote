#!/usr/bin/env python3
#
# __main__.py

from symbiote.app import entry_point

if __name__ == "__main__":
    entry_point()
